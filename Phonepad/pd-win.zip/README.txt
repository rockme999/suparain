=====================================
Phonepad Desktop v0.1.0
=====================================

[설치 방법]

1. Phonepad-0.1.0-windows.zip 압축 해제
2. phonepad_desktop.exe 실행

[Windows SmartScreen 경고 시]

처음 실행할 때 "Windows에서 PC를 보호했습니다" 메시지가 나타날 수 있습니다.

1. "추가 정보" 클릭
2. "실행" 클릭

이 경고는 서명되지 않은 앱에서 나타나는 정상적인 동작입니다.

[시스템 요구사항]

- Windows 10 이상 (64-bit)
- 모바일 앱과 동일한 WiFi 네트워크 또는 USB 연결

[사용 방법]

1. PC에서 Phonepad Desktop 실행
2. 스마트폰에서 Phonepad 앱 실행
3. 동일 네트워크에서 자동 검색 또는 IP 직접 입력
4. 연결 후 스마트폰을 숫자패드/미디어 컨트롤러로 사용

[문의]

GitHub: https://github.com/rockme999/Phonepad
